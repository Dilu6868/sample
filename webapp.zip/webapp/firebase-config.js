// firebase-config.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-auth.js";
import { getDatabase } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-database.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyChT5ryEMX26wC-7Fnw7HugI2hG_m-fk1Q",
  authDomain: "smartir-c0798.firebaseapp.com",
  databaseURL: "https://smartir-c0798-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "smartir-c0798",
  storageBucket: "smartir-c0798.firebasestorage.app",
  messagingSenderId: "476733676831",
  appId: "1:476733676831:web:d3a81e213d85acf065242a",
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const database = getDatabase(app);   // Realtime Database — Smart_IR_Devices (Button command)
export const firestore = getFirestore(app); // Firestore — device_registration + sensor_data
